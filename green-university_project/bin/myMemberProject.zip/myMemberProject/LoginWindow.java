package myMemberProject;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

public class LoginWindow {
	
	FrameController fc = new FrameController();
	
	public LoginWindow() {
		/* 로그인 Frame */
		fc.getLoginWindow();
		
		// 로그인 버튼
		fc.btn_login.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String sid = fc.id.getText();
				String spw = new String(fc.pw.getPassword());
				if(sid.equals("") || spw.equals(""))
				{
					new CommonPopup(1);		// "빈값은 입력할 수 없습니다."
				}
				else
				{
					boolean loginTF = loginCheck();
					if(loginTF)
					{
						fc.dispose();
						new MemberInfoWindow(fc.id.getText());
					}
					else
					{
						new CommonPopup(11);	// "비밀번호가 일치하지 않거나 해당 아이디가 존재하지 않습니다."
					}
				}
			}
		});
		
		// 회원가입 버튼
		fc.btn_join.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				fc.dispose();
				new JoinWindow();
			}
		});
		
		// 아이디/비밀번호찾기 버튼
		fc.btn_searchIDPW.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new SearchWindow();
			}
		});
	}
	
	public boolean loginCheck() {
		MemberDTO member = MemberDao.getMemberInfo(fc.id.getText());
		String spw = new String(fc.pw.getPassword());
		
		boolean result = false;
		// 받아온 객체가 null이면
		if(!Objects.isNull(member))
		{
			if(spw.equals(member.getPassword()))
				result = true;
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		new LoginWindow();
	}
}
