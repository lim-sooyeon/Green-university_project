package myMemberProject;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JoinWindow {
	
	FrameController fc = new FrameController();
	// 중복검사 클릭 건수 
	static int idCheckCnt = 0;
	
	public JoinWindow() {
		/* 회원가입 Frame */
		fc.getJoinWindow();

		// 저장 버튼 클릭 시 
		fc.btn_save.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String spw = new String(fc.pw.getPassword());		// PW
				String spwc = new String(fc.pwc.getPassword());		// PWC
				
				/* Field에서 받아온 정보를 String 배열로 저장 */
				String[] memberInfo = new String[11];
				memberInfo[0] = fc.id.getText();					// ID
				memberInfo[1] = new String(fc.pw.getPassword());	// PW
				memberInfo[2] = fc.email.getText() + fc.emailAddr.getSelectedItem(); // email
				memberInfo[3] = fc.name.getText();					// name
				memberInfo[4] = (String) (fc.year.getSelectedItem()) + fc.month.getSelectedItem() + fc.date.getSelectedItem(); // birth
				memberInfo[5] = fc.phone.getText();					// phone
				memberInfo[6] = (String) fc.gender.getSelectedItem();	// gender
				// member의 성적을 랜덤값으로 세팅
				int random = 0;
				int sum = 0;
				for(int i=0; i<3; i++)
				{
					random = (int)(Math.random()*100)+1;
					memberInfo[i+7] = Integer.toString(random);
					sum += random;
				}
				double avg = (double) sum / 3;
				memberInfo[10] = String.format("%.2f", avg);
				
				// TextField 중 빈값이 있는지 체크
				int blankCheckcnt = 0;
				for(int i=0; i<memberInfo.length; i++)
					if(memberInfo[i].equals("") || memberInfo[i] == "" || memberInfo[i] == null)
						blankCheckcnt++;
				
				// 8자리, 비밀번호 대소문자, 특수문자 체크
				String pwPattern = "^(?=.*\\d)(?=.*[~`!@#$%\\^&*()-])(?=.*[a-z])(?=.*[A-Z]).{8,20}$";
				Matcher matcher = Pattern.compile(pwPattern).matcher(spw);
				
				if (blankCheckcnt > 0)
				{
					new CommonPopup(1);		// "빈값은 입력할 수 없습니다."
				}
				else if (idCheckCnt == 0)
				{
					new CommonPopup(5);		// "중복검사 버튼을 클릭하세요";
				}	
//				else if (!matcher.matches())
//				{
//					System.out.println("폰번호이상함");
//				}
				else if (!spw.equals(spwc))
				{
					new CommonPopup(8);		// "비밀번호가 일치하지 않습니다."
				}
				else if (!matcher.matches())
				{
					new CommonPopup(6);		// "8자리 이상, 대소문자와 특수문자를 포함한 비밀번호를 입력해주세요."
					fc.pw.setText("");
					fc.pwc.setText("");
				}
				else if ((fc.phone.getText()).length() != 11)
				{
					new CommonPopup(15);	// "핸드폰번호는 11자리만 가능합니다."
				}
				else
				{
					/* text파일로 내보내기위해 IO작업하는 공통 메소드 호출 */
					MemberDao.joinMember(memberInfo);
					fc.dispose();
					new LoginWindow();
				}
			}
		});
		
		/* 아이디 중복검사 */
		fc.idCheck.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				/* text파일에 있는 정보를 가져오기위해 공통 메소드 호출*/
				HashMap<String, MemberDTO> members = MemberDao.getAllMemeber();
				
				if(!Objects.isNull(members))
				{
					if(members.containsKey(fc.id.getText()))
					{
						new CommonPopup(2);		// "이미 존재하는 아이디입니다."
						fc.id.setText("");
					}
					else
					{
						if((fc.id.getText()).equals(""))
						{
							new CommonPopup(1);		// "빈값은 입력할 수 없습니다."
						}
						else
						{
							idCheckCnt++;
							new CommonPopup(3);		// "사용할 수 있는 아이디입니다."
						}
					}
				}
				else
				{
					if((fc.id.getText()).equals(""))
					{
						new CommonPopup(1);		// "빈값은 입력할 수 없습니다."
					}
					else
					{
						idCheckCnt++;
						new CommonPopup(3);		// "사용할 수 있는 아이디입니다."
					}
				}
			}
		});
	}
}
